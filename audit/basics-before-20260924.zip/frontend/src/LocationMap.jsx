import {useEffect,useRef,useState} from 'react';
import {useTranslation} from 'react-i18next';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {api} from './api';
export default function LocationMap({onChoose,radius}){
 const {t}=useTranslation();const host=useRef(null),mapRef=useRef(null),handler=useRef(onChoose),circle=useRef(null),radiusRef=useRef(radius),[message,setMessage]=useState('map_hint');handler.current=onChoose;radiusRef.current=radius;
 useEffect(()=>{
  const map=L.map(host.current,{center:[10.95,78.45],zoom:7,scrollWheelZoom:false,attributionControl:false,zoomControl:false});mapRef.current=map;
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18}).addTo(map);
  let marker,controller;
  map.on('click',async e=>{
   const {lat,lng}=e.latlng;
   if(lat<8||lat>13.7||lng<76||lng>80.5){setMessage('outside_state');return}
   marker?.remove();circle.current?.remove();marker=L.circleMarker([lat,lng],{color:'#165f49',radius:7,fillOpacity:1}).addTo(map);circle.current=L.circle([lat,lng],{radius:radiusRef.current*1000,color:'#165f49',fillOpacity:.08}).addTo(map);
   controller?.abort();controller=new AbortController();const request=controller;setMessage('map_loading');
   try{const result=await api(`/geocode?lat=${lat}&lon=${lng}`,undefined,request.signal);handler.current({...result,lat,lon:lng});setMessage('map_selected')}
   catch(e){if(request.signal.aborted)return;if(e.message==='outside_state'){setMessage('outside_state');return}setMessage('map_failed');handler.current({location:`${lat.toFixed(4)}, ${lng.toFixed(4)}`,lat,lon:lng})}
  });
  return()=>{controller?.abort();map.remove()};
 },[]);
 useEffect(()=>circle.current?.setRadius(radius*1000),[radius]);
 return <div className="location-map"><p aria-live="polite">{t(message)}</p><div className="actions"><button type="button" onClick={()=>mapRef.current?.zoomIn()}>{t('zoom_in')}</button><button type="button" onClick={()=>mapRef.current?.zoomOut()}>{t('zoom_out')}</button></div><div className="map-surface" ref={host} role="region" aria-label={t('map_label')}/><small>© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> · {t('map_attribution')}</small></div>;
}
